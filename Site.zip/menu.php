<div class="header">
	<a class="link" href="#">Главная</a>
	<a class="link" href="puzzle.php">Загадки</a>
	<a class="link" href="guess.php">Угадайка</a>
	<a class="link" href="number.php">Угадайка на 2 игрока</a>
	<a class="link" href="password.php">Генератор пароля</a>
</div>