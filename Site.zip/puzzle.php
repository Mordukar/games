<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Личный сайт студента GeekBrains</title>
	<link rel="stylesheet" href="style.css"> 
	
</head>
<body>

	<div class="content">
		<div class="header">
			<a class="link" href="index.php">Главная</a>
			<a class="link" href="#">Загадки</a>
			<a class="link" href="guess.php">Угадайка</a>
			<a class="link" href="number.php">Угадайка на 2 игрока</a>
			<a class="link" href="password.php">Генератор пароля</a>
		</div>
		<div class="contentWrap">
			<h1 class="heading">Игра в загадки</h1>
			<div class="box">
				<?php
					if(isset($_GET['userAnswer1']) && isset($_GET['userAnswer2']) && isset($_GET['userAnswer3'])){
						
						$userAnswer = $_GET["userAnswer1"];
						$score = 0;
						if($userAnswer == "водопровод"){
							$score++;
						}
						$userAnswer = $_GET["userAnswer2"];
						if($userAnswer == "морковь"){
							$score++;
						}
						$userAnswer = $_GET["userAnswer3"];
						if($userAnswer == "крапива"){
							$score++;
						}
						echo "Вы угадали " . $score . " загадок";
					}
				?>
				<form method="GET">
					<p class="box__text">Речка спятила с ума — По домам пошла сама</p>
					<input type="text" name="userAnswer1">

					<p class="box__text">Сидит девица в темнице, коса на улице</p>
					<input type="text" name="userAnswer2">

					<p class="box__text">Не огонь, а жжётся</p>
					<input type="text" name="userAnswer3">

					<br>
					<input class="input" c type="submit" value="Ответить" name="">
				</form>
			</div>
			<div class="footer">
				Copyright &copy; Evgeny Sergeevich
			</div>
		</div>
	</div>
</body>
</html>


