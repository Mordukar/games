<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Личный сайт студента GeekBrains</title>
	<link rel="stylesheet" href="style.css"> 
</head>
<body>
<div class="content">
	<?php
		include "menu.php";
	?>
	<h1 class="heading">Личный сайт студента GeekBrains</h1>
	<div class="box_content">
		<p class="box__content_text"><b>Добрый день!</b></p>
		<p class="box__content_text">На этом сайте вы можете сыграть в несколько игр, которые я написал на языке JS: 
		<div><a class="box__content_link" href="puzzle.ph">Загадки</a></div>	
		<div><a class="box__content_link" href="puzzle.ph">Загадки</a></div>
		<div><a class="box__content_link" href="guess.php">Угадайка</a></div>
		<div><a class="box__content_link" href="number.php">Угадайка на 2 игрока</a></div>
		<div><a class="box__content_link" href="password.php">Генератор пароля</a></div>
		</p>
	</div>
	<div class="footer">
		Copyright &copy; <?php echo date("Y");?> Evgeny Sergeevich
	</div>
</div>
</body>
</html>